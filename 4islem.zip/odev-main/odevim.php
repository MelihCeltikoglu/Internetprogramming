<html>
<head>

</head>
<body>

<?php


$sayi1 = 20;
$sayi2 = 10;

echo " Toplama İslemi Sonucu : " .($sayi1 + $sayi2 )."<br />" ;
echo " Cıkarma İslemi Sonucu : " .($sayi1 - $sayi2 )."<br />";
echo " Bolme İslemi Sonucu : "   .($sayi1  / $sayi2 )."<br />" ;
echo " Carpma İslemi Sonucu : "  .($sayi1 * $sayi2 )."<br />";


?>
</body>
</html>